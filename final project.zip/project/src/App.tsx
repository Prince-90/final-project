import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Cloud, Droplets, Wind, ThermometerSun, CloudSun, Menu, X, Github, Twitter, Linkedin, Mail } from 'lucide-react';
import { WeatherData } from './types';

const CITIES = [
  'Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai',
  'Kolkata', 'Pune', 'Ahmedabad', 'Jaipur', 'Lucknow'
];

const API_KEY = import.meta.env.VITE_WEATHER_API_KEY;

function App() {
  const [weatherData, setWeatherData] = useState<Record<string, WeatherData>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);

  useEffect(() => {
    const fetchWeatherData = async () => {
      if (!API_KEY || API_KEY === 'YOUR_API_KEY') {
        setError('Please set up your OpenWeatherMap API key in the .env file');
        setLoading(false);
        return;
      }

      try {
        const promises = CITIES.map(city =>
          axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city},IN&units=metric&appid=${API_KEY}`)
        );
        
        const responses = await Promise.all(promises);
        const newWeatherData: Record<string, WeatherData> = {};
        
        responses.forEach(response => {
          newWeatherData[response.data.name] = response.data;
        });
        
        setWeatherData(newWeatherData);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch weather data. Please check your API key and try again.');
        setLoading(false);
      }
    };

    fetchWeatherData();
    const interval = setInterval(fetchWeatherData, 300000); // Update every 5 minutes

    return () => clearInterval(interval);
  }, []);

  const scrollToCity = (city: string) => {
    setSelectedCity(city);
    setIsMenuOpen(false);
    const element = document.getElementById(city);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
        <div className="text-white text-2xl">Loading weather data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-500 to-pink-600 flex items-center justify-center p-8">
        <div className="text-white text-xl text-center max-w-2xl">
          <p className="mb-4">{error}</p>
          {error.includes('API key') && (
            <div className="text-base opacity-90">
              <p className="mb-2">To fix this:</p>
              <ol className="list-decimal list-inside text-left space-y-2">
                <li>Sign up for a free API key at <a href="https://openweathermap.org/api" target="_blank" rel="noopener noreferrer" className="underline">OpenWeatherMap</a></li>
                <li>Create a .env file in the project root</li>
                <li>Add your API key: VITE_WEATHER_API_KEY=your_api_key_here</li>
                <li>Restart the development server</li>
              </ol>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex flex-col">
      {/* Navbar */}
      <nav className="bg-white/10 backdrop-blur-lg fixed w-full z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <CloudSun className="h-8 w-8 text-white" />
              <span className="ml-2 text-white font-bold text-xl">Indian Weather</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="flex space-x-4">
                {CITIES.map(city => (
                  <button
                    key={city}
                    onClick={() => scrollToCity(city)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors
                      ${selectedCity === city 
                        ? 'text-white bg-purple-600' 
                        : 'text-white/90 hover:bg-white/10'
                      }`}
                  >
                    {city}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-white hover:bg-white/10 focus:outline-none"
              >
                {isMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white/10 backdrop-blur-lg">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {CITIES.map(city => (
                <button
                  key={city}
                  onClick={() => scrollToCity(city)}
                  className={`block w-full text-left px-3 py-2 rounded-md text-base font-medium
                    ${selectedCity === city 
                      ? 'text-white bg-purple-600' 
                      : 'text-white/90 hover:bg-white/10'
                    }`}
                >
                  {city}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <div className="flex-grow pt-20 p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-white text-center mb-8">
            Indian Cities Weather Forecast
          </h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CITIES.map(city => {
              const data = weatherData[city];
              if (!data) return null;

              return (
                <div 
                  key={city} 
                  id={city}
                  className={`bg-white/90 backdrop-blur-lg rounded-lg p-6 shadow-lg hover:transform hover:scale-105 transition-transform duration-300
                    ${selectedCity === city ? 'ring-4 ring-purple-500 ring-opacity-50' : ''}`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-800">{city}</h2>
                      <p className="text-gray-600">{data.weather[0].description}</p>
                    </div>
                    <img 
                      src={`https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`}
                      alt={data.weather[0].description}
                      className="w-16 h-16"
                    />
                  </div>
                  
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center space-x-2">
                      <ThermometerSun className="text-orange-500" />
                      <span className="text-3xl font-bold text-gray-800">
                        {Math.round(data.main.temp)}°C
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div className="flex items-center space-x-2">
                        <Cloud className="text-blue-500" />
                        <span className="text-gray-600">Feels like {Math.round(data.main.feels_like)}°C</span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Droplets className="text-blue-500" />
                        <span className="text-gray-600">{data.main.humidity}%</span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Wind className="text-blue-500" />
                        <span className="text-gray-600">{Math.round(data.wind.speed)} m/s</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white/10 backdrop-blur-lg mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* About Section */}
            <div>
              <div className="flex items-center mb-4">
                <CloudSun className="h-8 w-8 text-white" />
                <span className="ml-2 text-white font-bold text-xl">Indian Weather</span>
              </div>
              <p className="text-white/80 text-sm">
                Stay updated with real-time weather information for major Indian cities. 
                Data refreshes every 5 minutes to ensure you have the latest weather updates.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Quick Links</h3>
              <div className="grid grid-cols-2 gap-2">
                {CITIES.slice(0, 6).map(city => (
                  <button
                    key={city}
                    onClick={() => scrollToCity(city)}
                    className="text-white/80 hover:text-white text-left text-sm"
                  >
                    {city}
                  </button>
                ))}
              </div>
            </div>

            {/* Connect Section */}
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Connect With Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-white/80 hover:text-white transition-colors">
                  <Github className="h-6 w-6" />
                </a>
                <a href="#" className="text-white/80 hover:text-white transition-colors">
                  <Twitter className="h-6 w-6" />
                </a>
                <a href="#" className="text-white/80 hover:text-white transition-colors">
                  <Linkedin className="h-6 w-6" />
                </a>
                <a href="#" className="text-white/80 hover:text-white transition-colors">
                  <Mail className="h-6 w-6" />
                </a>
              </div>
              <p className="mt-4 text-white/80 text-sm">
                Powered by OpenWeatherMap API
              </p>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-white/10">
            <p className="text-center text-white/60 text-sm">
              © {new Date().getFullYear()} Indian Weather. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;